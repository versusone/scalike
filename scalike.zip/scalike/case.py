## This file is part of the Software: scalike.
## This file and scalike are provided under the MIT licence:
## The MIT Licence can be found at: https://tldrlegal.com/license/mit-license#fulltext
## and in the file LICENCE.txt of the current directory of the software.
##
## Copyright (c) 2007-2008, Patrick Germain Placidoux
## All rights reserved.
##
## Permission is hereby granted, free of charge, to any person obtaining a copy
## of this software and associated documentation files (the "Software"), to deal
## in the Software without restriction, including without limitation the rights
## to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
## copies of the Software, and to permit persons to whom the Software is
## furnished to do so, subject to the following conditions:
##
## The above copyright notice and this permission notice shall be included in all
## copies or substantial portions of the Software.
##
## THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
## IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
## FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
## AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
## LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
## OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
## SOFTWARE.
##
##  @author: Patrick Germain Placidoux
##  @contact: scalike@gmx.com



"""
* -------------------------------------------------------------------------------------------------------------------- *
|                                                           CASE (Experimental)                                        |
* -------------------------------------------------------------------------------------------------------------------- *

---------------------
| CASE INTRODUCTION |
---------------------

There are three elements entering into play considering using cases for Data dispatching:

- The Case Schema
- The Case Property
- The Switch Operator literally: with Switch(<iterable>) as case
- Iterable filtering, this works on the case instance.
- Iterable Mapping, this works on the Case Property instance


1.) The Case Schema

1.1  Creating a Schema the simplest way :

>>> mySchema = CaseSchema('a', 'b', 'c')
This creates a simple schema with three fields of type String.

The following CaseSchema methods can be used on mySchema :
mySchema.ofields()
str(mySchema) or mySchema.wks()

>>> mySchema.ofields() # ofields means ordered fields
('a', 'b', 'c')
>>> str(mySchema)
{'a': {'*type': 'str', '*required': True}, 'b': {'*type': 'str', '*required': True},
'c': {'*type': 'str', '*required': True}}

As we can see each field is defined by a key-value pair:
<field name> : <type>
Syntax:
-------
<field name> : always a string.
<type> : a wk expression.
    a wk expression is a dictionary with a particular format.
    Run help(wk) to learn more on wk expression.

There is also 3 more methods:
- addField(*fe)
- reorderFields(*field_names)
- delField(field_name)


1.2  Creating a Schema using wk expression :

ex1:
>>> mySchema = CaseSchema( 'a',     # must be  an str
      ('b', {'*type': bool}),   # must be a bool
      ('c', {'*type': tuple})    # must be a tuple
)

ex2:
>>> mySchema = CaseSchema(
      ('a', {'*type': 'int', '*ge': 3}), # must be an int and greater than 3.
      ('b', {'*date': "%d/%m/%Y"}), # must be a date expedcted format is a string formatted like : '01/11/2016'.
      ('c', {'*ts': '%d/%m/%Y %Hh%Mmn%Ss'}), # Expects a string formatted TimeStamp like this: '01/11/2016 16h40mn3s'.
      ('d', {'*type': 'dict', '*dtype': {'a': {'*type': 'str'}, 'b': {'*type': 'bool'}}}), # must be a dict with keys a,b.
)

>>> str(mySchema)
"{'a': {'*type': 'int', '*ge': 3, '*required': True},
'b': {'*date': '%d/%m/%Y', '*required': True},
'c': {'*ts': '%d/%m/%Y %Hh%Mmn%Ss', '*required': True},
'd': {'*type': 'dict', '*dtype': {'a': {'*type': 'str'},
'b': {'*type': 'bool'}}, '*required': True}}"


1.2  Creating a Schema from an empty constructor :

>>> mySchema = CaseSchema()
>>> mySchema.addField('a')
>>> mySchema.addField('b', {'*type': 'int'})
>>> mySchema.addField('c', {'*type': 'bool'})

>>> str(mySchema)
"{'a': {'*type': 'str', '*required': True}, 'b': {'*type': 'int', '*required': True}, 'c': {'*type': 'bool', '*required': True}}"


2.) The Case Property

>>> myCaseProperty = mySchema(['a1', 2, True])
or:
>>> myCaseProperty = mySchema(['a1', 2, True],  '%', '%', '%')
or:
>>> myCaseProperty = mySchema(['a1', 2, True],  '%a', '%b', '%c')

>>> str(myCaseProperty)
"{'a': 'a1', 'b': 2, 'c': True}"

Some CaseProperty usefull methods are:
myCaseProperty.fields()
myCaseProperty.ofields()
myCaseProperty.wks()
myCaseProperty.setField(name, value):
myCaseProperty.getField(name)




3.) The Switch Operator literally: with Switch(<iterable>) as case

4.) Iterable filtering, this works on the case instance.
5.) Iterable Mapping, this works on the Case Property instance



1/
def myMapFunction(e):
    with Switch(e) as case: # e can be any python value or a list (or a tuple).

        if case('lola', ooo): # here either e is not a list (or tuple) and e must be equal to 'lola'.
                              # e is a list (or tuple) and first item must be 'lola'.
            ...
        if case(o, o, {'*type': 'bool'}): # e must be a list of 3 elements and third one must be a bool.
            ...

        if case(o, {'*reg': r'[a-z]*'}): # Second element of the list e must satisfy the regular expression.
            ...

        elif if case(o,'a', o, o, 'z'):
            doSomething
        else:
            doOtherStuff

l.map(myMapFunction)

2/
def myMapFunction(e):
    with Switch(e) as case: # e can be any python value or a list (or a tuple).

        if case(ooo, o,  'p*', o, {'*type': 'int', '*required': True}, {'*type': 'list'}): # here a list of at least five elements is expected.
            # This will filter user starting with 'p' and age not None, must be int.
            # Last item must be a list.

            # This creates a caseProperty for the mapped user.
            cu = caseIhsLogFormat(e, ooo, o, '%user', o, '%age', '%address', '%friends')
            print cu.user
            print cu.age

            # Recursive:
            cu.add(myMapFunction(cu.friends))

        if case(o,'a', o, o, o,'b','c', o, o, o):
            ...
        elif if case(o,'a', o, o, 'z'):
            doSomething
        else:
            doOtherStuff

l.map(myMapFunction)



-------------------
| CASES USE CASES |
-------------------


0/ SAMPLE ANALYSING HUGE FILES (Gigas long) :
   ------------------------------------------

SAMPLE DATASOURCE:
For our case study we'll use an Apache server log for SSL analysis as Data Source.
This file sizes multiple Gigas octets.

We open Python interpreter:

fd = open(apache.log)
lines = fd.readlines()
fd.close()

_ First 2 lines are:
lines = [
'192.123.234.012 - - "[29/Aug/2017:02:00:46 +0200]" "POST /my/uri HTTP/1.1" 200 624 "Apache CXF 3.0.4" "TLSv1.2" "AES128-SHA256" "BACKEND_SERVER1" "193.108.111.231" "www.my.site.com" "text/xml; charset=UTF-8" "-"',
'192.123.234.013 - - "[29/Aug/2017:02:00:46 +0200]" "POST /my/uri HTTP/1.1" 200 624 "Apache CXF 3.0.4" "TLSv1.2" "AES128-SHA256" "BACKEND_SERVER1" "193.108.111.231" "www.my.site.com" "text/xml; charset=UTF-8" "-"'
]

_ An arbitrary shlex on it guives :
>>> record = shlex.split(lines[0])
['192.123.234.012', '-', '-', '[29/Aug/2017:02:00:46 +0200]', 'POST /my/uri HTTP/1.1',
'200', '624', 'Apache CXF 3.0.4', 'TLSv1.2', 'AES128-SHA256', 'BACKEND_SERVER1',
'193.108.111.231', 'www.my.site.com', 'text/xml; charset=UTF-8', '-']
>>> len(line)
15
we will consider the following iterable:




1.) Making the case schema

_ First sample line is:
line = '
192.123.234.012 - - "[29/Aug/2017:02:00:46 +0200]" "POST /my/uri HTTP/1.1" 200 624 "Apache CXF 3.0.4" "TLSv1.2" "AES128-SHA256" "BACKEND_SERVER1" "193.108.111.231" "www.my.site.com" "text/xml; charset=UTF-8" "-"
'

_ An arbitrary shlex on it guives :
>>> line = shlex.split(line.strip())
['192.123.234.012', '-', '-', '[29/Aug/2017:02:00:46 +0200]', 'POST /my/uri HTTP/1.1', '200', '624', 'Apache CXF 3.0.4', 'TLSv1.2',
'AES128-SHA256', 'BACKEND_SERVER1', '193.108.111.231', 'www.my.site.com', 'text/xml; charset=UTF-8', '-']
>>> len(line)
15

1.1) Field dispatch:

0 to 2 Trash: '192.123.234.012', '-', '-',
a) 3 TimeStamp, Type: *ts --> '[29/Aug/2017:02:00:46 +0200]',
4 Trash: 'POST /my/uri HTTP/1.1',
b) 5 Response Code, Type: int --> '200',
6 to 7 Trash: '624', 'Apache CXF 3.0.4',
c) 8 SSL Protocol --> 'TLSv1.2',
d) 9 SSL CIPHER --> 'AES128-SHA256',
10 Trash: 'BACKEND_SERVER1',
e) 11 IP --> '193.108.111.231',
12 to 14 Trash: 'www.my.site.com', 'text/xml; charset=UTF-8', '-'

# See later: cu = sslCaseSchema(o,o,o, ts, o, rcode, o,o, protocol, cipher, o, ip, ooo)

1.1) Complexe Types formatting:
a) TimeStamp Formatting:
_ Testing our split lambda function:
>>>  '[29/Aug/2017:02:00:46 +0200]'.split()[0][1:]
'29/Aug/2017:02:00:46'
Our function will be: lambda e: e.split()[0][1:]

_ Testing *ts in wk
>>> p = wk.WKS()
>>> p.ts = {'*ts': '%d/%b/%Y:%H:%M:%S'}
>>> wk.check(p, {'ts': '29/Aug/2017:02:00:46'})
>>> p.ts
datetime.datetime(2017, 8, 29, 2, 0, 46) # ok:
# We could check this also:
>>> p = wk.WKS()
>>> p.ts = {'*ts': '%d/%b/%Y:%H:%M:%S', '*withConvert':lambda e:e.split()[0][1:], '*type': 'str'}
>>> wk.check(p, {'ts': '[29/Aug/2017:02:00:46 +0200]'})
>>> p.ts
datetime.datetime(2017, 8, 29, 2, 0, 46) # ok

=> So we are sure that our Case constructor will gracefully support a wk on the TimeStamp.

1.2) Building the CaseSchema instance
sslCase = CaseSchema(('ts', {'*ts': '%d/%b/%Y:%H:%M:%S', '*withConvert':lambda e:e.split()[0][1:], '*type': 'str'}), ('rcode', {'*type': int, '*withEval': True}), 'protocol', 'cipher', 'ip')

2.) Running a map filter

Complete source:
----------------
wk : convert
map : ignore_none

import shlex, datetime
from scalike import *
lines = sclist('
192.123.234.012 - - "[29/Aug/2017:02:00:46 +0200]" "POST /my/uri HTTP/1.1" 200 624 "Apache CXF 3.0.4" "TLSv1.2" "AES128-SHA256" "BACKEND_SERVER1" "193.108.111.231" "www.my.site.com" "text/xml; charset=UTF-8" "-"
')

sslCaseSchema = CaseSchema(('ts', {'*ts': '%d/%b/%Y:%H:%M:%S', '*withConvert':lambda e:e.split()[0][1:], '*type': 'str'}), ('rcode', {'*type': int, '*withEval': True}), 'protocol', 'cipher', 'ip')
def f(e):
    e = shlex.split(e) # must be an Iterable
    with Switch(e) as case:
        # Use do_raise=True first time you run f(e) ==> if not case(o,o,o, '[*', o, {'*type': 'int', '*withEval': True}, ooo, do_raise=True):return None
        if not case(o,o,o, '[*', o, {'*type': 'int', '*withEval': True}, ooo):return None
        # Creating our ssl record:
        cp = sslCaseSchema(e, o,o,o, '%ts', o, '%rcode', o,o, '%protocol', '%cipher', o, '%ip', ooo)
        myts = datetime.datetime(2015, 2, 28, 1, 1, 1)
        if cp.ts < myts: return None
        if (cp.protocol.startswith('SSL') or cs.protocol.startswith('RC4')):return None

        return cs

# ignore_none and  force_ignore allow map to acte as a filter for None value returned by fct.
l = lines.map(f, ignore_none=True, force_ignore=True)

# e.g.2:
l.map(lambda e: e.fields())
"""


import wk
import scexception
import random
random.seed()

o = '__O_SCALIKE_OTHER_TRIVIAL_DUMMY_ELEMENT__'
ooo = '__OOO_SCALIKE_OTHER_TRIVIAL_CONTINUE_ELEMENT__'

# ------------ #
# caseDigester #
# ------------ #

class caseDigester(object):

    @staticmethod
    def check(l, formats=None, do_raise=False, do_transform=True, matches=None):
        """
:argument l: a list or tuple of entries to check against the formats list if exists..
All matched entries will fill the matches list, if matches is provided.

:param formats: A list or tuple of format elements.
If formats is not provided all the entries of the list l is matched for the matches list and True is returned.

When formats is provided the value of the formats list is used to:
    - check parts of the list l.
    - map parts of the list l with some fields of the Case schema.
A format element can be a:
    - _ : to map anything,
    Beware that you must import scalike like this:
     from scalike impport * to have direct acces to _ in your code.
     Otherwise you should write scalike._.

    -  Any correct python value will this value
    -  Any correct wk explression.
        e.g.: {'*type': 'int'},
        {'*type': 'bool'} or
        { '*type': dict, '*dtype': {'name': {'*type': 'str'}, 'age': {'*type': 'int'}} }

Litteral checks Examples:
-------------------------
e.g.1:
    formats = (o, o, o, o)
    Will macth a list of four elements.

e.g.2:
    formats = (o, o, o, ooo)
    Will macth a list starting at least with three elements.

e.g.3:
    formats = (ooo, o, o, o)
    Will macth a list ending at least with three elements.

e.g.4:
    formats = ('smith', '179.101.10.10', o, ooo)
    Will macth a list starting at least with three elements.
    But the first one must be 'smith'.
    The second one must be 179.101.10.10.

e.g.5:
    formats = ('smith', o, '179.101.10*', '*45016895', True, ('new york', 'bombay'))
    Will macth a list of 6 elements.
    But the first one must be 'smith'.
    The second can be anything.
    The third one must start with 179.101.10..
    The fourth one must end with 45016895.
    The fifth must be a (python type boolean) True.
    The sixth must match python type tuple with value: ('new york', 'bombay').

    Note: any python types are supported in the formats list.

e.g.6:
    formats = (ooo, o, {'*type': 'dict'}, o)
    Here the third expression must match a wks expression.
    Note: Any wks expression is supported.

:param do_raise: If True (default False) will raise an Exception when an error occures.
Otherwise return None.

:param do_transform: If True (default True), when check passed, transformations are applied.
For example, if a wk expression transforms a value, this new value is kept for the resulting
field. It is this new value that would be added to the matches list.
e.g:    {'*type': 'str', '*value': 'california'} : because of the presence of the '*value' key which applies a
        default value of 'california'. If the received entry is None, it would be replaced by 'california'.

        {'*type': 'int', 8} would replace None by 8.
        { '*type': dict, '*dtype': {'name': {'*type': 'str', '*value': 'jonh'}, 'age': {'*type': 'int', '*value': 20}} }
        would replace None by {'name': 'jonh', 'age': 20}

:param matches: If a list (not a tuple) is provided as parameter, this list will be filled with evrery matched entry.

:return True if all checks passed !
"""
        selfMethod='check'
        if not isinstance(l, (tuple, list)):raise scexception.scParameterTypeException('l', 'list/tuple', str(l), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
        if formats!=None and (not isinstance(formats, (tuple, list)) or len(formats)==0):raise scexception.scParameterTypeException('formats', 'list/tuple', str(formats), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
        if not isinstance(do_raise, (bool)):raise scexception.scParameterTypeException('do_raise', 'bool', str(do_raise), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
        if not isinstance(do_transform, (bool)):raise scexception.scParameterTypeException('do_transform', 'bool', str(do_transform), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
        if matches!=None and not isinstance(matches, (list)):raise scexception.scParameterTypeException('matches', 'list', str(matches), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
        formats=list(formats)

        prefix='Echec Trying to digest list: %s !\n' % (l,)
        if matches==None:matches=[]

        if formats == None:
            matches.extend(l)
            return True

        l_start_index = 0
        # l_end_index = len(formats) -1


        # Startswith: ooo:
        # ---------------
        if formats[0] == ooo:
            del formats[0]
            if len(formats) > len(l):
                msg = 'formats ooo... : %s, with length of: %s, is longer than list: %s !' % (formats, len(formats), len(l))
                if do_raise:raise scexception.scSystemException(prefix + msg)
                else:return False

            l_start_index = len(l) - len(formats)


        # Endswith ooo: Already the default
        # -------------
        elif formats[-1] == ooo:
            del formats[-1]
            if len(formats) > len(l):
                msg = 'Formats ...ooo : %s, with length of: %s, is longer than the List: %s !' % (formats, len(formats), len(l))
                if do_raise:raise scexception.scSystemException(prefix + msg)
                else:return False

        # Same as:
        # -------------
        elif len(formats) != len(l):
                msg = 'Formats: %s, with length of: %s, should be the size of the List: %s !' % (formats, len(formats), len(l))
                if do_raise:raise scexception.scSystemException(prefix + msg)
                else:return False


        # Check all:
        # ----------
        l_index = l_start_index
        for i in range(len(formats)):
            l_value = l[l_index]
            frt_value = formats[i]
            l_index +=1
            msg = 'List entry: %s at index: %s do not match Format element: %s, at index: %s ! ' % (l_value, l_index, frt_value, i)

            # wk:
            if isinstance(frt_value, dict):
                # Check formats entry is a wk expression {'*type', 'int'}, {'*reg': 'name\s*:(.*)'}?
                try:
                    wk.isWKDefinition(frt_value, class_exit=caseDigester.__class__.__name__, method_exit=selfMethod)

                    # Check wk expression:
                    p = wk.WantedKeywords()
                    setattr(p, str(i), frt_value)
                    wk.getKeywords(wantedKeywords=p, keywords={str(i): l_value}, class_exit=caseDigester.__class__.__name__, method_exit=selfMethod)

                    if do_transform:value = getattr(p, str(i))
                    else:value = l_value

                    # Result list:
                    matches.append( value )

                    continue

                except Exception as e:
                    if do_raise:raise scexception.scSystemException(prefix + msg + ' SubException is:' + str(e), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
                    return False

            # _:
            if frt_value == o:
                matches.append(l_value)
                continue

            # Endswith:
            if isinstance(frt_value, str) and frt_value.startswith('*'):
                if not l_value.endswith(frt_value[1:]):return False
                else:
                    matches.append(l_value)
                    continue

            # Startswith: ...:
            if isinstance(frt_value, str) and frt_value.endswith('*'):
                if not l_value.startswith(frt_value[:-1]):return False
                else:
                    matches.append(l_value)
                    continue

            # Any python expression:
            if l_value != frt_value:return False
            else:
                matches.append(l_value)
                continue

        return True

    @staticmethod
    def map(l, formats=None, ordered_fields=None, do_raise=False):
        """
:argument l: a list or tuple of entries to macth against the formats and ordered_fields list if exists..

:param ordered_fields: (required) a list or tuple of field names.

:param formats: A list or tuple of format elements.
If formats is not provided all the entries of the list l is taken to try to the match ordered_fields.

When formats is provided the value of the formats list is used to:
    - retreive parts of the list l.
    - map parts of the list l with some fields name of the ordered_fields.

A format element can be a:
    -  o: to ignore this entry,
    Beware that you must import scalike like this:
     from scalike import * to have direct acces to o and ooo in your code.
     Otherwise you should write scalike.o or  scalike.ooo.

    -  %: stands for Trivial mapping.
        Use % to map the next field of the ordered_fields.
        When Trivial mapping is used:
            - Declared mapping cannot be.
            - All the fields of the ordered_fields must be provided.

    -  %<name>: stands for Declared mapping.
        Use %<name> to map the field named: <name> within the ordered_fields list of names.
        When Declared mapping is used:
            -  Trivial mapping cannot be.
            - All the fields of the ordered_fields must be provided.

Case mapping Examples:
---------------------
e.g.1:
formats = ('%', _, _, '%', '%')
    Will macth a list of 5 elements.
    The elements ticked by % will match the ordered_fields list of names in this order.
    The length of the ordered_fields list must be 3.

e.g.2:
formats = ('.., 'smith', '%b', _, _, '%c', '%a')
    %b will map the the property's field named b.
    %c will map the the property's field named c.
    %a will map the the property's field named a.
    At the end of the list l.
    The ordered_fields list (or tuple)  must be ('a', 'b', 'c') in any order.

e.g.3:
formats = ('%b', _, _, '%c', '%a', ___)
    %b will map the the property's field named b.
    %c will map the the property's field named c.
    %a will map the the property's field named a.
    At the beginning of the list l.
    The ordered_fields list (or tuple) must be ('a', 'b', 'c') in any order.


:param do_raise: If True (default False) will raise an Exception when an error occures.
Otherwise return None.

:return a dict of matched field names.
        """
        selfMethod='map'
        founds={}
        if not isinstance(l, (tuple, list)):raise scexception.scParameterTypeException('l', 'list/tuple', str(l), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
        if formats in (None, (), []):
            if len(l)!= len(ordered_fields):raise scexception.scParameterException('formats', 'When Formats is not provided list length (%s) must be equal to the fields length (%s) !' % (len(l), len(ordered_fields)), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
            for i in range(len(ordered_fields)): founds[ordered_fields[i]]=l[i]
            return founds


        if not isinstance(formats, (tuple, list)) or len(formats)==0:raise scexception.scParameterTypeException('formats', 'Required list/tuple', str(formats), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
        if not isinstance(ordered_fields, (tuple, list)) or len(ordered_fields)==0:raise scexception.scParameterTypeException('ordered_fields', 'Required list/tuple', str(ordered_fields), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
        if not isinstance(do_raise, (bool)):raise scexception.scParameterTypeException('do_raise', 'bool', str(do_raise), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
        formats = list(formats)
        prefix='Echec Trying to digest list:\n%s !\n' % (l,)

        l_start_index = 0
        # l_end_index = len(formats) -1

        trivial_mapping = False
        declared_mapping = False
        next_field_index=0

        # Startswith: ooo:
        # ---------------
        if formats[0] == ooo:
            del formats[0]
            if len(formats) > len(l):
                msg = 'formats ooo... : %s, with length of: %s, is longer than list: %s !' % (formats, len(formats), len(l))
                if do_raise:raise scexception.scSystemException(prefix + msg)
                else:return False

            l_start_index = len(l) - len(formats)


        # Endswith ooo: Already the default
        # -------------
        elif formats[-1] == ooo:
            del formats[-1]
            if len(formats) > len(l):
                msg = 'Formats ...ooo : %s, with length of: %s, is longer than the List: %s !' % (formats, len(formats), len(l))
                if do_raise:raise scexception.scSystemException(prefix + msg)
                else:return False

        # Same as:
        # -------------
        elif len(formats) != len(l):
                msg = 'Formats: %s, with length of: %s, should be the size of the List: %s !' % (formats, len(formats), len(l))
                if do_raise:raise scexception.scSystemException(prefix + msg)
                else:return False


        # Map all:
        # --------
        l_index = l_start_index
        for i in range(len(formats)):
            l_value = l[l_index]
            frt_value = formats[i]
            l_index +=1
            if frt_value == o:continue

            msg = 'List entry: %s at index: %s do not match Format element: %s, at index: %s ! ' % (l_value, l_index, frt_value, i)

            if not isinstance(frt_value, (str,)):raise scexception.scSystemException(prefix + 'Incorrect Format expression: %s (type:  %s) at index: %s ! Expected an str.' % (str(frt_value).replace(ooo, 'ooo'), type(frt_value), i), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
            if not frt_value[0]=='%':raise scexception.scSystemException(prefix + 'Incorrect Format expression: ' + str(frt_value).replace(ooo, 'ooo')  + ' at index: ' + str(i) + ' ! Should start with %.', fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)

            # Trivial Mapping:
            if len(frt_value)==1:trivial_mapping = True
            # Declared Mapping:
            if len(frt_value)>1:declared_mapping = True
            if trivial_mapping and declared_mapping:raise scexception.scSystemException(prefix + 'Incompatible format expression found: ' + str(frt_value).replace(ooo, 'ooo') + ' at index: ' + str(i) + ' ! Trivial mapping (%) and Declared Mapping (%<name>) cannot be used together.', fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)

            if trivial_mapping:
                if next_field_index>=len(ordered_fields):raise scexception.scSystemException(prefix + 'Incompatible Trivial Mapping at index: %s ! No more field to map found.' % (i,), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)
                founds[ordered_fields[next_field_index]]=l_value

                next_field_index+=1

            if declared_mapping:
                field_name=frt_value[1:]
                try:
                    CaseSchema.checkFieldName(field_name)
                except:raise

                if field_name not in ordered_fields:raise scexception.scSystemException(prefix + 'Incompatible Declared Mapping: %s at index: %s ! Field: %s not found.' % (frt_value, i, field_name), fromClass=caseDigester.__class__.__name__, fromMethod=selfMethod)

                founds[field_name]=l_value


        return founds



# ------ #
# Switch #
# ------ #

class Switch(caseDigester):
    """
    Thanks to Ian Bell on http://stackoverflow.com/questions/60208/replacements-for-switch-statement-in-python
    """
    def __init__(self, l):
        selfMethod='__init__'
        if not isinstance(l, (tuple, list)):l=(l,)
        self.__value = tuple(l)
        self.__matches = []
    def __enter__(self): return self
    def __exit__(self, type, value, traceback): return False
    def __call__(self, *formats, do_raise=False, do_transform=True):
        selfMethod = '__call__'
        if not isinstance(do_raise, (bool)):raise scexception.scParameterTypeException('do_raise', 'bool', str(do_raise), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if not isinstance(do_transform, (bool)):raise scexception.scParameterTypeException('do_transform', 'bool', str(do_transform), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if len(formats) == 0: formats = None
        self.__matches=[]

        return caseDigester.check(self.__value, formats=formats, do_raise=do_raise, do_transform=do_transform, matches=self.__matches)


# ---- #
# Case #
# ---- #


class CaseSchema(caseDigester):
    """
A Case defines the structure (or schema) expected from a list or tuple.
The case instance defines the type (and more) for each entry within the input list (or tuple).
You can think a Case as a schema definition for a record (the input list).
    """

    allowed_flags = ['boolConversionString', 'noneConvertionString']

    def __init__(self, *args, **flags):
        """
Syntax: Case(<entry_name>,  [(<entry_name>, <entry_type>)], ..., boolConversionString = (<string_value>, <string_value>), noneConvertionString = <string_value>)
    <entry_name>: is a simple str expression with no space, this will be the name of the field for this entry.
    This fall under the supported name attribute's syntax for a python instance.

    <entry_type>: this a wks expression (see the full doc wk.pdf at www.kikonf.org). This is viewed in more details below.
        Shortly a wks expression is a dict which specifies type and characteristics fo a field.

1. simple constructor call:
    CaseSchema(<entry_name>, <entry_name>, <entry_name>)

myCase = CaseSchema('a', 'b', 'c')
This construct a schema for a case record with fields defined in this order :
a --> Must be str
b --> Must be str
c --> Must be str

2. mixed call:
    CaseSchema(<entry_name>, (<entry_name>, <entry_type>), <entry_name>)

myCase =  CaseSchema(
    'a',
    ('b', {'*type': 'int'}),
    ('c', {'*required': False}),
)
This construct a schema for a case record with fields defined in this order :
a --> Expected str
b --> Expected int
c --> Expected str and the field c is not mandatory.
    Note: if *type is not provided, default *type is str.
    By default all field are required.


3. More complex mixed call:
    CaseSchema(<entry_name>, (<entry_name>, <entry_type>), ...)

myCase =  CaseSchema(
    'a',
    ('b', {'*eq': 'rate'}),
    ('c', {'*value': 'rate'}),
    ('d', {'*type': 'int'}),
    ('e', {'*type': 'int', '*withEval': True}),
    ('f', {'*type': 'int', '*gt': 5}),
    ('g', {'*type': 'int', '*between': (5, 10)}),
    ('h', {'*type': 'bool'}),
    ('i', {'*type': 'bool', '*eq': True}),
    ('j', {'*type': 'list'}),
    ('k', {'*type': 'dict'}),
    ('l', {'*type': 'list', '*ltype': {'*type': int}}),
    ('m', {'*type': 'dict', '*dtype' : {'a1': {'*type':str}, 'b1': {'*type':int}, 'c1': {'*type': bool}}}),
)
This construct a schema for a case record with fields defined in this order :
a --> Expected any str
b --> Expected str and value must be 'rate'
c  --> Expected str but if the value of this entry is None it is replaced by 'rate'
d --> Expected int
e --> Expected int but if is a str will try to evaluate to an int.
    *withEval can be used with any of the wk expression types to silently convert them from str to the
    python type pointed by *type.
    Note: For security with eval use a restricted python eval.

f --> Expected int greater than 5
g --> Expected int between 5 and 10
h --> Expected bool
i --> Expected bool and must be True
j --> Expected list
k --> Expected dict
l --> Expected list of int
m --> Expected dict (remember that python dict are unordered) with key defined as:
    a1 --> str
    b1 --> int
    c1 --> bool

4. Calling the constructor with no arguments :

The constructor can be called with no argument:
myCase =  CaseSchema()

Then after each entry can be defined like this:
Please note that fields order is registred in the order of the addFields calls.

myCaseSchema.addField('a')
myCaseSchema.addField('b', {'*type': int})
myCaseSchema.addField('c', {'*type': 'date'})

5. Constructor flags:
For now these flags are allowed and must be passed as keywords, after the list of arguments:

    CaseSchema(<entry_name>,  [(<entry_name>, <entry_type>)], ..., boolConversionString = (<string_value>, <string_value>), noneConvertionString = <string_value>)
    e.g.:
        boolConversionString = ('true', 'false')
        noneConvertionString = 'null'

    A flag value must always be a string with no space.
    If provided, conversions are applied first, before any field and type checks.

    If the boolConversionString  flag is provided with value ('true', 'false') for instance:
        any of the entry of the list with a value of 'true' will be converted to python boolean True.
        any of the entry of the list with a value of 'false' will be converted to python boolean False.

    If the noneConvertionString  flag is provided with value 'null' for instance:
        any of the entry of the list with a value of 'null' will be converted to python None type.
        """
        selfMethod = '__init__'
        self.__ordered_fields = []
        self.__wks = {}
        self.__boolConversionString = None
        self.__noneConvertionString = None

        # ------------- #
        # Checking args #
        # ------------- #

        ##?No argumetns:
        if len(args) == 0:return

        ## ?Mixed arguments:
        for arg in args:
            field_name, wks = CaseSchema.checkFieldEntry(arg, class_exit=self.__class__.__name__, method_exit=selfMethod)
            if field_name in self.__ordered_fields:raise scexception.scSystemException('This field name: %s is defined more than once !' % (field_name, ), fromClass=self.__class__.__name__, fromMethod=selfMethod)
            self.__ordered_fields.append(field_name)
            self.__wks[field_name] = wks

        # -------------- #
        # Checking flags #
        # -------------- #

        for flag in flags:
            if not flag in CaseSchema.allowed_flags:
                raise scexception.scSystemException('Inccorrect flag: %s ! Supported flags are: %s.' % (flag, ', '.join(CaseSchema.allowed_flags)), fromClass=self.__class__.__name__, fromMethod=selfMethod)

            if flags[flag]==None:pass
            elif flag == 'boolConversionString':
                if not isinstance(flags[flag], (list, tuple)):raise scexception.scSystemException('Inccorrect value for flag boolConversionString ! Expected a tuple (or a list) of two values. Received: ' % (str(flags[flag])), fromClass=self.__class__.__name__, fromMethod=selfMethod)
                if not len(flags[flag])==2:raise scexception.scSystemException('Inccorrect value for flag boolConversionString ! Expected a tuple (or a list) of two values. Received: ' % (str(flags[flag])), fromClass=self.__class__.__name__, fromMethod=selfMethod)

                for f in flags[flag]:
                    if not isinstance(f, str):raise scexception.scSystemException('Inccorrect value for flag boolConversionString ! Expected a tuple (or a list) of two str. Received: ' % (str(flags[flag])), fromClass=self.__class__.__name__, fromMethod=selfMethod)
                    if ' ' in f:raise scexception.scSystemException('Inccorrect value for flag boolConversionString ! Expected a tuple (or a list) of two str with no space. Received: ' % (str(flags[flag])), fromClass=self.__class__.__name__, fromMethod=selfMethod)

                self.__boolConversionString = tuple(flags['boolConversionString'])

            elif flag == 'noneConvertionString':
                if not isinstance(flags[flag], str):raise scexception.scSystemException('Inccorrect value for flag noneConvertionString ! Expected an str. Received: ' % (str(flags[flag])), fromClass=self.__class__.__name__, fromMethod=selfMethod)
                if ' ' in flags[flag]:raise scexception.scSystemException('Inccorrect value for flag noneConvertionString ! Should not contain space. Received: ' % (str(flags[flag])), fromClass=self.__class__.__name__, fromMethod=selfMethod)

                self.__noneConvertionString = flags['noneConvertionString']

    @staticmethod
    def checkFieldEntry(fe, class_exit=None, method_exit=None):
        selfMethod='checkFieldEntry'
        if isinstance(fe, (tuple, list)):
            if not len(fe) == 2:raise scexception.scSystemException('Inccorrect expression for this field: %s ! Expected a list (or tuple) pair of <field_name>/wks or <filed_name>.' % (str(fe),), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod + " SubClass:" + str(class_exit) + " SubMethod:" + str(method_exit))
            field_name = fe[0]
            wks = fe[1]

            # Check field_name
            CaseSchema.checkFieldName(field_name, class_exit=CaseSchema.__class__.__name__, method_exit=selfMethod)

            # Check type
            try:
                wk.isWKDefinition(wks, class_exit=CaseSchema.__class__.__name__, method_exit=selfMethod)
            except Exception as  e:
                raise scexception.scSystemException('Echec trying to set wk expression: %s for field: %s. SubException is: %s' % (str(wks), field_name, str(e)), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)

        else:
            field_name = fe
            # Check field_name
            CaseSchema.checkFieldName(field_name, class_exit=CaseSchema.__class__.__name__, method_exit=selfMethod)
            wks={'*type': 'str'}

        if '*required' not in wks:wks['*required'] = True

        return field_name, wks

    @staticmethod
    def checkFieldName(field_name, class_exit=None, method_exit=None):
        selfMethod='checkFieldName'
        if not isinstance(field_name, (str,)) or not field_name[0].isalpha():raise scexception.scSystemException('Inccorrect field name: %s ! Expected an alphanum expression (may contain "_").' % (str(field_name),), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod + " SubClass:" + str(class_exit) + " SubMethod:" + str(method_exit))
        field_name = field_name.replace('o', '')
        if not field_name.isalnum():raise scexception.scSystemException('Inccorrect field name: %s ! Expected an alphanum expression (may contain "_").' % (str(field_name),), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod + " SubClass:" + str(class_exit) + " SubMethod:" + str(method_exit))
        if field_name.find(' ')>=0:raise scexception.scSystemException('Inccorrect field name: %s ! Expected an alphanum expression with no space (may contain "_").' % (str(field_name),), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod + " SubClass:" + str(class_exit) + " SubMethod:" + str(method_exit))

        return True

    def addField(self, *fe):
        selfMethod='addField'
        if len(fe) == 1:fe=fe[0]
        if len(fe)>2:raise scexception.scSystemException('Case:addField: Unsupported list of arguments args: should not be greater than 2 !', fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)
        field_name, wks = CaseSchema.checkFieldEntry(fe, class_exit=self.__class__.__name__, method_exit=selfMethod)

        self.__ordered_fields.append(field_name)
        self.__wks[field_name] = wks

    def reorderFields(self, *field_names):
        """
        :param field_names: an ordered suite of field names, these name must all already exist within this Case instance.
        And all the previously regfistred field names within this Case instance, must appears in this field names suite.

        This method will reorder the fields into the Case record schema.
        This wont affect previously created Property.
        But only the next Prorperty generation.

        Note: properties are created with the myCase.makeProperty(l) or myCase.mkv(l) method.

        """
        selfMethod='reorderFields'
        for fn in field_names:
            if fn not in self.__ordered_fields:raise scexception.scSystemException('Must support field: %s ! Supported fields are: %s.' % (str(fn), ', '.join(self.__ordered_fields)), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)

        for fn in self.__ordered_fields:
            if fn not in field_names:raise scexception.scSystemException('Unsupported field: %s ! Supported fields are: %s.' % (str(fn), ', '.join(self.__ordered_fields)), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)

        self.__ordered_fields = list(field_names)

    def clone(self):
        """
        This will clone this Case instance.
         This allows you to create alike Cases.
        """
        params = []
        for fn in self.__ordered_fields:params.append((fn, self.__wks[fn]))
        return CaseSchema(*params, **{'boolConversionString': self.__boolConversionString, 'noneConvertionString': self.__noneConvertionString})

    def wks(self):
        return dict(self.__wks)

    def ofields(self):
        return tuple(self.__ordered_fields)

    def delField(self, field_name):
        selfMethod='delField'
        if field_name not in self.__ordered_fields:raise scexception.scSystemException('Unsupported field: %s ! Supported fields are: %s.' % (str(field_name), ', '.join(self.__ordered_fields)), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)
        self.__ordered_fields.remove(field_name)
        del self.__wks[field_name]

    # makeProperty
    def __call__(self, l, *formats, do_raise=False):
        selfMethod='__call__'
        if not isinstance(do_raise, (bool)):raise scexception.scParameterTypeException(
            'do_raise', 'bool', str(do_raise), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        founds=caseDigester.map(l, formats=formats, ordered_fields=tuple(self.__ordered_fields), do_raise=do_raise)
        if founds == None:return

        try:
            cp=caseProperty(tuple(self.__ordered_fields), self.__wks, founds)
        except Exception as e:
            raise
            if do_raise:raise scexception.scSystemException('Echec trying to make caseProperty ! SubExpression is: %s.' % (str(e),), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)
            return None

        return cp

    def __str__(self):
        return str(self.__wks)


# --------------- #
#   CaseProperty  #
# --------------- #

class caseProperty(caseDigester):
    intial_datas = ['__fields', '__wks']

    def __init__(self, ordered_fields, wks, fields=None, lock=True):
        selfMethod='__init__'
        # Because of __getattr__ and __setattr__ all initials attrs must be placed before the "self.lock=lock" instruction.
        self.__ordered_fields = tuple(ordered_fields)
        self.__fields = {}
        self.__wks = dict(wks)
        self.lock=lock

        l = list(ordered_fields)
        l.sort()
        ll = list(wks.keys())
        ll.sort()

        if l != ll:raise scexception.scParameterException('ordered_fields/wks', 'ordered_fields and wks should be of the same size and have the same keys !', fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)
        if fields!=None:self.setFields(dict(fields), do_raise=True)

    def wks(self):
        return dict(self.__wks)

    def ofields(self):
        return tuple(self.__ordered_fields)

    def fields(self):
        return dict(self.__fields)

    def getFields(self):
        return dict(self.__fields)

    def __getattr__(self, name):
        selfMethod='__getattr__'
        if '_caseProperty__ordered_fields' not in self.__dict__:raise TypeError('Unknown Attribute: %s' % name)
        ordered_fields = self.__dict__['_caseProperty__ordered_fields']

        if name in ordered_fields:return self.getField(name)
        if name in self.__dict__:return [name]
        raise TypeError('Unknown Attribute: %s' % name)

    def __setattr__(self, name, value):
        selfMethod='__setattr__'

        if '_caseProperty__ordered_fields' not in self.__dict__ or 'lock' not in self.__dict__:
            self.__dict__[name] = value
            return
        ordered_fields = self.__dict__['_caseProperty__ordered_fields']

        if name in ordered_fields:
            return self.setField(name, value)
        else:
            if self.lock:raise scexception.scSystemException('Because this caseProperty is locked, You cannot trivial attr on it !', fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)
            self.__dict__[name] = value

    def __delattr__(self, name):
        selfMethod='__delattr__'
        ordered_fields = self.__dict__['_caseProperty__ordered_fields']

        if name in ordered_fields:raise scexception.scSystemException('Deletting a caseProperty field is disallowed !', fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)
        else:del self.__dict__[name]

    def unLock(self):
        self.__dict__['lock'] = False

    def setField(self, name, value):
        selfMethod='setField'
        if not name in self.__ordered_fields:raise scexception.scSystemException('Unsupported field: %s ! Supported fields are: %s.' % (str(name), ', '.join(self.__ordered_fields)), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)

        p = wk.WantedKeywords()
        setattr(p, name, self.__wks[name])
        try:
            wk.getKeywords(wantedKeywords=p, keywords={name: value}, class_exit=str(self.__class__), method_exit=selfMethod)
        except Exception as e:raise scexception.scSystemException('Echec trying to set value: %s, for field: %s ! SubException is: %s' % (value, name, str(e)), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        self.__fields[name] = getattr(p, name)

        return self.__fields[name]

    def getField(self, name):
        selfMethod='getField'
        if not name in self.__ordered_fields:raise scexception.scSystemException('Unsupported field: %s ! Supported fields are: %s.' % (str(name), ', '.join(self.__ordered_fields)), fromClass=CaseSchema.__class__.__name__, fromMethod=selfMethod)

        return self.__fields[name]

    # Check Properties
    def checkFields(self, do_raise=False):
        selfMethod='checkFields'
        if do_raise != None and not isinstance(do_raise, (bool)): raise scexception.scParameterTypeException('do_raise', 'bool', str(do_raise), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        try:
            p = wk.WantedKeywords()
            for key in self.__wks:
                setattr(p, key, self.__wks[key])
            wk.getKeywords(wantedKeywords=p, keywords=self.__fields, class_exit=str(self.__class__),
                           method_exit=selfMethod)
        except:
            if do_raise:raise
            return False

        return True

    # Check Properties
    def check(self, do_raise=False):
        return self.checkFields(self, do_raise=do_raise)

    # map
    def map(self, l, *formats, do_raise=False):
        selfMethod='map'
        if do_raise != None and not isinstance(do_raise, (bool)): raise scexception.scParameterTypeException('do_raise', 'bool', str(do_raise), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        founds=caseDigester.map(l, formats=formats, ordered_fields=tuple(self.__ordered_fields), do_raise=do_raise)
        if founds==None:return False

        return self.setFields(founds, do_raise=do_raise)

    # Feed Property
    def setFields(self, d, do_raise=False):
        selfMethod='setFields'
        if not isinstance(d, (dict)): raise scexception.scParameterTypeException('d', 'dict', str(d), fromClass=self.__class__.__name__, fromMethod=selfMethod)
        if not isinstance(do_raise, (bool)): raise scexception.scParameterTypeException('do_raise', 'bool', str(do_raise), fromClass=self.__class__.__name__, fromMethod=selfMethod)

        try:
            p = wk.WantedKeywords()
            for key in self.__wks:
                setattr(p, key, self.__wks[key])
            wk.getKeywords(wantedKeywords=p, keywords=d, class_exit=str(self.__class__), method_exit=selfMethod)
            self.__fields.clear()
            self.__fields.update(wk.getAsDict(p))
        except:
            if do_raise:raise
            return False

        return True

    def accept(self, visitor, childFirst = True, treatChilds=True, treatFirstNode=True, _isFirstNode=True):
        if childFirst or (not treatFirstNode):
            if treatChilds:
                for child in self.__childs:child.accept(visitor, childFirst = childFirst, _isFirstNode=False)

            if treatFirstNode:
                if _isFirstNode:visitor.visitFirstNode(self)
                else:visitor.visit(self)

        else:

            if treatFirstNode:
                if _isFirstNode:visitor.visitFirstNode(self)
                else:visitor.visit(self)

            if treatChilds:
                for child in self.__childs:child.accept(visitor, childFirst = childFirst, _isFirstNode=False)

    def __str__(self):
        return str(dict(self.__fields))


